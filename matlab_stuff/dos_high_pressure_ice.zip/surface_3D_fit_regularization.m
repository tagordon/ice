%% Import data
% close all
% clear all

addpath('./Thermo_LBF_Tools/');

high_pressure_ice_DOS;

n = 50;
X_data = [dos.T_array zeros(1,n) ones(1,n)*150.0];
Y_data = [dos.VovVo  linspace(min(dos.VovVo),max(dos.VovVo),n) linspace(min(dos.VovVo),max(dos.VovVo),n)];
Z_data = [dos.Evib_array  zeros(1,n) zeros(1,n)];
% X_data = [dos.T_array];
% Y_data = [dos.VovVo ];
% Z_data = [dos.Evib_array   ];
% Check input data
figure(2)
plot3(X_data,Y_data,Z_data,'ko');
xlabel('X values')
ylabel('Y values')
zlabel('z values')
grid on

%% Evaluating spline with regularization
% spline evaluation range (Should always be greater than data range)
X_range = [min(X_data) max(X_data)];
Y_range = [min(Y_data) max(Y_data)]; 

dZ = 1;

% chose number of control points for P and T and set the grid of control points

nxc=6;  % adjust these to chnage the numbers of control points
nyc=7;  % adjust these to chnage the numbers of control points
Xc=linspace(-1,X_range(2),nxc);
Xc=[0 logspace(-1,2,50) 150 200 300 700 1000 2000];
Yc=linspace(Y_range(1),Y_range(2),nyc);
options.Xc={Xc,Yc};



% The values given below were manually adjusted to achieve a reduced chi square of about 1
% change these numbers to see the effect on misfits and smoothness of the resulting surface
% smaller values for less misfit and less "smoothness", larger values for greater misfit and smoothness

options.mdrv = [2 2]; % derivative for which regularization is applied on X and Y (default 2nd)

options.lam=[90e2 2e1];  % intensity of regularization

options.ordr=[5 5]; % order of the spline


% RegFac is a vector of integers for the regularization oversampling (number of regularization pts between each control point)
%           if RegFac is not included in options, the default  is 1 for all dimensions     
%           if RegFac is included but empty, do a least square fit without regularization
%                (likely to fail unless data coverage is adequate)  
options.RegFac = [5 1];     

% all other options are allowed to be the default values

% since data are scattered, input X is a matrix with as many columns as
% independent variables

sp=spdft([X_data(:) Y_data(:)],Z_data(:),dZ(:),options);


figure (1)
subplot(2,2,1)
fnplt(sp)
hold on
plot3(X_data,Y_data,Z_data,'ko','MarkerFaceColor','k')
hold off
xlabel('Temperature (K)')
ylabel('V/Vo')
zlabel('Evib (J/kg)')

sp_Cv= fnder(sp,[1 0]);


subplot(2,2,2)
plot3(X_data,Y_data,(Z_data-fnval(sp,[X_data ;Y_data]))./Z_data,'ko','MarkerFaceColor','k')

subplot(2,2,3)
fnplt(sp_Cv)
